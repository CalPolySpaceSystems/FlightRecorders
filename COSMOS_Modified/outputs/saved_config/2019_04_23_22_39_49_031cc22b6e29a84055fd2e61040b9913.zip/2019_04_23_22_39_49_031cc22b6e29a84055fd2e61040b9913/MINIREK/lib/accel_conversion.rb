# Implements a conversion factor for accelerometer data

require 'cosmos/conversions/conversion'

module Cosmos
  class AccelConversion < Conversion
    def initialize(axis)
      super()
      @axis = axis
    end        
    def call(value, packet, buffer)
      if axis == 1                    # X
        if packet.digits[?] == 1      # Course accel sensor
          conversionFactor = 0.00305  # Hi-G factor
        else if packet.digits[?] == 1 # Fine accel sensor
          conversionFactor = 0.000493 # Course Accel factor
        else
          conversionFactor = 0.000062 # Fine accel factor
        end
      else if axis == 2               # Y
        if packet.digits[?] == 1      # Course accel sensor
          conversionFactor = 0.00305  # Hi-G factor
        else if packet.digits[?] == 1 # Fine accel sensor
          conversionFactor = 0.000493 # Course Accel factor
        else
          conversionFactor = 0.000062 # Fine accel factor
        end
      else                            # Z
        if packet.digits[?] == 1      # Course accel sensor
          conversionFactor = 0.00305  # Hi-G factor
        else if packet.digits[?] == 1 # Fine accel sensor
          conversionFactor = 0.000493 # Course Accel factor
        else
          conversionFactor = 0.000062 # Fine accel factor
        end
      end
      return value * #conversion factor	
    end
  end
end