# Implements a conversion factor for gyroscope data

require 'cosmos/conversions/conversion'

module Cosmos
  class GyroConversion < Conversion
    def call(value, packet, buffer)
		  return (value*500.0) / 32768.0	
    end
  end
end