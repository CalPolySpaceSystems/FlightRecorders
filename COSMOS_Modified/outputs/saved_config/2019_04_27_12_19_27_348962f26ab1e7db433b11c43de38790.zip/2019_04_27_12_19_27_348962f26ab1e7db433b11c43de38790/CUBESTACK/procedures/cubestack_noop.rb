require 'cosmos'
require 'cubestack.rb'

cubestack = Cubestack.new
cubestack.noop
